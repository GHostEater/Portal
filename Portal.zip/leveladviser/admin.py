# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from leveladviser.models import LevelAdviser

# Register your models here.

admin.site.register(LevelAdviser)
