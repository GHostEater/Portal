# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin

from college.models import College

# Register your models here.

admin.site.register(College)
