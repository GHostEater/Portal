# -*- coding: utf-8 -*-
from cgpa_calculator import cgpa_calculator
