# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin

from modeofentry.models import ModeOfEntry

# Register your models here.

admin.site.register(ModeOfEntry)
