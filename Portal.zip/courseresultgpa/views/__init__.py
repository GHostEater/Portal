# -*- coding: utf-8 -*-
from course_result_gpa import CourseResultGPAAPIView, CourseResultGPACreateAPIView, CourseResultGPADetailAPIView
from course_result_gpa_student import CourseResultGPAStudentAPIView
from course_result_gpa_dept import CourseResultGPADeptAPIView
from raw_result_and_cgpa import raw_result_and_cgpa
from raw_result_and_cgpa_specific import raw_result_and_cgpa_specific
from release_result_and_cgpa import release_result_and_cgpa
from release_result_and_cgpa import result_test
