# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from hod.models import Hod

# Register your models here.

admin.site.register(Hod)
